#removes spaces from string
s = input("Enter a string:")
print(s.replace(" ",""))