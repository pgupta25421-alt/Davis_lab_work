#calculation of even numbers from 1 to N
n = int(input("Enter number:"))
for i in range(2,n+1,2):
    print(i,end=" ")
    