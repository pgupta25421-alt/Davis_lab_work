# Find largest among 3 numbers
a, b, c = map(int, input("Enter three numbers").split())

if a >= b and a >= c:
    print(a)
elif b >= a and b >= c:
    print(b)
else:
    print(c)
    

