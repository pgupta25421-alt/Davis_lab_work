keys = ('a', 'b', 'c')
values = (1, 2, 3)

result = {}
for i in range(len(keys)):
    result[keys[i]] = values[i]

print("Dictionary:", result)





#output
# Dictionary: {'a': 1, 'b': 2, 'c': 3}