set1 = {1, 2, 3, 4}
set2 = {3, 4, 5, 6}

intersection = set1 & set2
difference = set1 - set2

print("Intersection:", intersection)
print("Difference:", difference)




#output
#Intersection: {3, 4}
#Difference: {1, 2}