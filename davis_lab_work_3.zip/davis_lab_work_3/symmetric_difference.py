set1 = {1, 2, 3}
set2 = {3, 4, 5}

result = set1 ^ set2

print("Symmetric Difference:", result)





#output
# Symmetric Difference: {1, 2, 4, 5