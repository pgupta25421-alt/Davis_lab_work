list1 = [3, 1, 2]
list2 = [2, 4, 5]

merged = list1 + list2

unique = []
for i in merged:
    if i not in unique:
        unique.append(i)

unique.sort()
print("Result:", unique)


#output

#Result: [1, 2, 3, 4, 5]