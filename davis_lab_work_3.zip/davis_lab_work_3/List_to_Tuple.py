lst = [1, 2, 2, 3, 4, 4]

unique = []
for i in lst:
    if i not in unique:
        unique.append(i)

result = tuple(unique)
print("Tuple:", result)



#output

#Rotated List: [40, 50, 10, 20, 30]