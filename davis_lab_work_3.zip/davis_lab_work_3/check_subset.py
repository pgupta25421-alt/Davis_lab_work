set1 = {1, 2}
set2 = {1, 2, 3, 4}

print("Is subset:", set1.issubset(set2))





#output
# Is subset: True