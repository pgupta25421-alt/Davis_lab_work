lst = [{1, 2}, set(), {3, 4}, set()]

result = []
for i in lst:
    if i != set():
        result.append(i)

print("Result:", result)



#output
#Result: [{1, 2}, {3, 4}]