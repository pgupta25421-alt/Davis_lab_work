nested = [[1, 2], [3, 4], [5]]

flat = []
for sublist in nested:
    for item in sublist:
        flat.append(item)

print("Flattened:", flat)


#output
#Flattened: [1, 2, 3, 4, 5]