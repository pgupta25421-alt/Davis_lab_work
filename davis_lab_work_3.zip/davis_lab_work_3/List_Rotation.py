# Rotate list to the right by k positions
lst = [10, 20, 30, 40, 50]
k = 2

k = k % len(lst)  # handle large k
rotated = lst[-k:] + lst[:-k]

print("Rotated List:", rotated)



#output
#Rotated List: [40, 50, 10, 20, 30]