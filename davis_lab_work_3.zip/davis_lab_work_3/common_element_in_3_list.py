l1 = [1, 2, 3]
l2 = [2, 3, 4]
l3 = [2, 5, 3]

result = []
for i in l1:
    if i in l2 and i in l3:
        result.append(i)

print("Common Elements:", result)


#output
#Common Elements: [2, 3]